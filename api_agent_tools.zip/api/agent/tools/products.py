"""
Product-related tools for the agent.

Provides capabilities for:
- Listing and searching products
- Creating new products
- Updating product visibility and pricing
- Managing product configurations
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# List products with filtering
list_products = ToolDefinition(
    name="list_products",
    description="List products with optional filtering by brand, category, or status. Returns paginated results with basic product info.",
    parameters=[
        ToolParameter(
            name="brand_id",
            type="integer",
            description="Filter by brand ID",
            required=False,
        ),
        ToolParameter(
            name="category_id",
            type="integer", 
            description="Filter by category ID",
            required=False,
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status (true/false)",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum number of products to return (1-100, default 20)",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number of products to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/products",
    method="GET",
)


# Get product by ID
get_product = ToolDefinition(
    name="get_product",
    description="Get detailed information about a specific product including pricing and visibility configurations.",
    parameters=[
        ToolParameter(
            name="product_id",
            type="integer",
            description="The product ID to retrieve",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/products/{product_id}",
    method="GET",
)


# Get product by code
get_product_by_code = ToolDefinition(
    name="get_product_by_code",
    description="Get detailed product information using the product code (e.g., '10335', '203486').",
    parameters=[
        ToolParameter(
            name="code",
            type="string",
            description="The unique product code",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/products/by-code/{code}",
    method="GET",
)


# Create product
create_product = ToolDefinition(
    name="create_product",
    description="Create a new product with pricing and visibility configurations. Use this for adding new products to the system.",
    parameters=[
        ToolParameter(
            name="brand_id",
            type="integer",
            description="Brand ID the product belongs to",
            required=True,
        ),
        ToolParameter(
            name="brand_category_id",
            type="integer",
            description="Brand category ID",
            required=True,
        ),
        ToolParameter(
            name="name",
            type="string",
            description="Product name (e.g., '5 Star Cadbury (Rs. 5 pack)')",
            required=True,
        ),
        ToolParameter(
            name="code",
            type="string",
            description="Unique product code",
            required=True,
        ),
        ToolParameter(
            name="gst_rate",
            type="number",
            description="GST rate percentage",
            required=True,
        ),
        ToolParameter(
            name="gst_category",
            type="string",
            description="GST category (e.g., 'REGULAR', 'EXEMPT')",
            required=True,
        ),
        ToolParameter(
            name="description",
            type="string",
            description="Product description",
            required=False,
        ),
        ToolParameter(
            name="barcode",
            type="string",
            description="Product barcode",
            required=False,
        ),
        ToolParameter(
            name="hsn_code",
            type="string",
            description="HSN code for tax purposes",
            required=False,
        ),
        ToolParameter(
            name="prices",
            type="array",
            description="List of price configurations per area with MRP and margins",
            required=False,
            items={"type": "object"},
        ),
        ToolParameter(
            name="visibility",
            type="array",
            description="List of visibility configurations per area and trade type (for_general, for_modern, for_horeca)",
            required=False,
            items={"type": "object"},
        ),
    ],
    endpoint="/companies/{company_id}/products",
    method="POST",
)


# Update product
update_product = ToolDefinition(
    name="update_product",
    description="Update an existing product's information. Only provided fields will be updated.",
    parameters=[
        ToolParameter(
            name="product_id",
            type="integer",
            description="The product ID to update",
            required=True,
        ),
        ToolParameter(
            name="name",
            type="string",
            description="New product name",
            required=False,
        ),
        ToolParameter(
            name="description",
            type="string",
            description="New product description",
            required=False,
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Set active status",
            required=False,
        ),
    ],
    endpoint="/companies/{company_id}/products/{product_id}",
    method="PATCH",
)


# Get products for a specific shop
get_products_for_shop = ToolDefinition(
    name="get_products_for_shop",
    description="Get products available for a specific shop based on route and area assignments with area-specific pricing.",
    parameters=[
        ToolParameter(
            name="shop_id",
            type="string",
            description="Shop/Retailer UUID",
            required=True,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum number of products to return",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number of products to skip",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/products/shop/{shop_id}",
    method="GET",
)


# All product tools
PRODUCT_TOOLS = [
    list_products,
    get_product,
    get_product_by_code,
    create_product,
    update_product,
    get_products_for_shop,
]

