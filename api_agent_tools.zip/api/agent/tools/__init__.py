"""
Tool definitions for the Sales Management Agent.

Each tool maps to one or more FastAPI endpoints and provides
the agent with capabilities to query and modify data.
"""

from api.agent.tools.products import PRODUCT_TOOLS
from api.agent.tools.areas import AREA_TOOLS
from api.agent.tools.routes import ROUTE_TOOLS
from api.agent.tools.distributors import DISTRIBUTOR_TOOLS
from api.agent.tools.analytics import ANALYTICS_TOOLS
from api.agent.tools.users import USER_TOOLS

# All available tools
ALL_TOOLS = [
    *PRODUCT_TOOLS,
    *AREA_TOOLS,
    *ROUTE_TOOLS,
    *DISTRIBUTOR_TOOLS,
    *ANALYTICS_TOOLS,
    *USER_TOOLS,
]

__all__ = [
    "PRODUCT_TOOLS",
    "AREA_TOOLS", 
    "ROUTE_TOOLS",
    "DISTRIBUTOR_TOOLS",
    "ANALYTICS_TOOLS",
    "USER_TOOLS",
    "ALL_TOOLS",
]

