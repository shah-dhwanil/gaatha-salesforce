"""
Analytics and reporting tools for the agent.

These are composite tools that combine data from multiple endpoints
to provide insights and answer analytical questions.

Note: Some of these may require additional backend endpoints to be created.
For now, they use existing endpoints with client-side aggregation.
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# Get sales performance by area
# Note: This would ideally call a dedicated analytics endpoint
# For now, it can use route logs and order data
get_sales_by_area = ToolDefinition(
    name="get_sales_by_area",
    description="Get sales performance data for areas. Use this to analyze which areas have sales drops or growth.",
    parameters=[
        ToolParameter(
            name="area_type",
            type="string",
            description="Level to analyze: ZONE, REGION, AREA, or DIVISION",
            required=False,
            enum=["ZONE", "REGION", "AREA", "DIVISION"],
            default="REGION",
        ),
        ToolParameter(
            name="parent_area_id",
            type="integer",
            description="Parent area ID to filter (e.g., get all regions in a zone)",
            required=False,
        ),
        ToolParameter(
            name="days",
            type="integer",
            description="Number of days to analyze (default 7)",
            required=False,
            default=7,
        ),
        ToolParameter(
            name="compare_previous",
            type="boolean",
            description="Compare with previous period",
            required=False,
            default=True,
        ),
    ],
    endpoint="/companies/{company_id}/analytics/sales-by-area",  # Needs to be created
    method="GET",
)


# Get route performance
get_route_performance = ToolDefinition(
    name="get_route_performance",
    description="Get performance metrics for routes. Identifies low-performing and top-performing routes.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Filter by area ID",
            required=False,
        ),
        ToolParameter(
            name="days",
            type="integer",
            description="Number of days to analyze",
            required=False,
            default=7,
        ),
        ToolParameter(
            name="sort_by",
            type="string",
            description="Sort by metric: sales, visits, orders",
            required=False,
            enum=["sales", "visits", "orders"],
            default="sales",
        ),
        ToolParameter(
            name="order",
            type="string",
            description="Sort order: asc (lowest first) or desc (highest first)",
            required=False,
            enum=["asc", "desc"],
            default="asc",
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Number of routes to return",
            required=False,
            default=10,
        ),
    ],
    endpoint="/companies/{company_id}/analytics/route-performance",  # Needs to be created
    method="GET",
)


# Get top salesmen
get_top_salesmen = ToolDefinition(
    name="get_top_salesmen",
    description="Get top performing salesmen by sales value, orders, or visits.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Filter by area ID",
            required=False,
        ),
        ToolParameter(
            name="period",
            type="string",
            description="Time period: today, week, month, or custom",
            required=False,
            enum=["today", "week", "month", "custom"],
            default="month",
        ),
        ToolParameter(
            name="start_date",
            type="string",
            description="Start date for custom period (YYYY-MM-DD)",
            required=False,
        ),
        ToolParameter(
            name="end_date",
            type="string",
            description="End date for custom period (YYYY-MM-DD)",
            required=False,
        ),
        ToolParameter(
            name="metric",
            type="string",
            description="Metric to rank by: sales, orders, visits",
            required=False,
            enum=["sales", "orders", "visits"],
            default="sales",
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Number of top salesmen to return",
            required=False,
            default=10,
        ),
    ],
    endpoint="/companies/{company_id}/analytics/top-salesmen",  # Needs to be created
    method="GET",
)


# Get stock by product
get_stock_by_product = ToolDefinition(
    name="get_stock_by_product",
    description="Get current stock levels for a product across distributors. Use product name or code to find stock.",
    parameters=[
        ToolParameter(
            name="product_code",
            type="string",
            description="Product code to check stock for",
            required=False,
        ),
        ToolParameter(
            name="product_name",
            type="string",
            description="Product name (partial match) to check stock for",
            required=False,
        ),
        ToolParameter(
            name="area_id",
            type="integer",
            description="Filter by area ID",
            required=False,
        ),
        ToolParameter(
            name="area_name",
            type="string",
            description="Filter by area name (e.g., 'Mumbai', 'South Surat')",
            required=False,
        ),
    ],
    endpoint="/companies/{company_id}/analytics/stock-by-product",  # Needs to be created
    method="GET",
)


# Get distributor stock list
get_distributor_stock = ToolDefinition(
    name="get_distributor_stock",
    description="Get full stock list for distributors in an area. Shows all products and quantities.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Area ID to get distributor stocks for",
            required=False,
        ),
        ToolParameter(
            name="area_name",
            type="string",
            description="Area name (e.g., 'South Surat', 'Mumbai Region')",
            required=False,
        ),
        ToolParameter(
            name="distributor_id",
            type="string",
            description="Specific distributor UUID to get stock for",
            required=False,
        ),
    ],
    endpoint="/companies/{company_id}/analytics/distributor-stock",  # Needs to be created
    method="GET",
)


# All analytics tools
ANALYTICS_TOOLS = [
    get_sales_by_area,
    get_route_performance,
    get_top_salesmen,
    get_stock_by_product,
    get_distributor_stock,
]

