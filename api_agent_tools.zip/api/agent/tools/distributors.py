"""
Distributor-related tools for the agent.

Provides capabilities for:
- Listing and searching distributors
- Getting distributor stock levels
- Managing distributor routes
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# List distributors with filtering
list_distributors = ToolDefinition(
    name="list_distributors",
    description="List distributors with optional filtering by area and status. Returns distributor details with route count.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Filter by area ID",
            required=False,
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum distributors to return (default 20, max 100)",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/distributors",
    method="GET",
)


# Get distributor by ID
get_distributor = ToolDefinition(
    name="get_distributor",
    description="Get detailed information about a specific distributor including routes, bank details, and trade types.",
    parameters=[
        ToolParameter(
            name="distributor_id",
            type="string",
            description="The distributor UUID to retrieve",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/distributors/{distributor_id}",
    method="GET",
)


# Get distributor by code
get_distributor_by_code = ToolDefinition(
    name="get_distributor_by_code",
    description="Find a distributor by their unique code.",
    parameters=[
        ToolParameter(
            name="code",
            type="string",
            description="Distributor code to search for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/distributors/by-code/{code}",
    method="GET",
)


# Get distributors by area
get_distributors_by_area = ToolDefinition(
    name="get_distributors_by_area",
    description="Get all active distributors for a specific area. Useful for finding distributors in a region or zone.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Area ID to get distributors for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/distributors/area/{area_id}/distributors",
    method="GET",
)


# Get distributors by trade type
get_distributors_by_trade = ToolDefinition(
    name="get_distributors_by_trade",
    description="Filter distributors by trade types (general, modern, HORECA). At least one trade type must be specified.",
    parameters=[
        ToolParameter(
            name="for_general",
            type="boolean",
            description="Filter by general trade flag",
            required=False,
        ),
        ToolParameter(
            name="for_modern",
            type="boolean",
            description="Filter by modern trade flag",
            required=False,
        ),
        ToolParameter(
            name="for_horeca",
            type="boolean",
            description="Filter by HORECA trade flag",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum distributors to return",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/distributors/by-trade/filter",
    method="GET",
)


# Get distributor statistics
get_distributor_stats = ToolDefinition(
    name="get_distributor_stats",
    description="Get count of active distributors with optional area filter.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Optional area ID to filter by",
            required=False,
        ),
    ],
    endpoint="/companies/{company_id}/distributors/stats/counts",
    method="GET",
)


# All distributor tools
DISTRIBUTOR_TOOLS = [
    list_distributors,
    get_distributor,
    get_distributor_by_code,
    get_distributors_by_area,
    get_distributors_by_trade,
    get_distributor_stats,
]

