"""
Route-related tools for the agent.

Provides capabilities for:
- Listing and searching routes
- Getting route performance data
- Managing route assignments
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# List routes with filtering
list_routes = ToolDefinition(
    name="list_routes",
    description="List routes with optional filtering by area, status, and trade type (general, modern, horeca).",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Filter by area (division) ID",
            required=False,
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status",
            required=False,
        ),
        ToolParameter(
            name="is_general",
            type="boolean",
            description="Filter by general trade routes",
            required=False,
        ),
        ToolParameter(
            name="is_modern",
            type="boolean",
            description="Filter by modern trade routes",
            required=False,
        ),
        ToolParameter(
            name="is_horeca",
            type="boolean",
            description="Filter by HORECA routes",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum routes to return (default 20, max 100)",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/routes",
    method="GET",
)


# Get route by ID
get_route = ToolDefinition(
    name="get_route",
    description="Get detailed information about a specific route including full area hierarchy context.",
    parameters=[
        ToolParameter(
            name="route_id",
            type="integer",
            description="The route ID to retrieve",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/routes/{route_id}",
    method="GET",
)


# Get route by code
get_route_by_code = ToolDefinition(
    name="get_route_by_code",
    description="Find a route by its unique code.",
    parameters=[
        ToolParameter(
            name="code",
            type="string",
            description="Route code to search for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/routes/by-code/{code}",
    method="GET",
)


# Get routes by area
get_routes_by_area = ToolDefinition(
    name="get_routes_by_area",
    description="Get all active routes for a specific area. Useful for finding routes in a region.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Area ID to get routes for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/routes/area/{area_id}/routes",
    method="GET",
)


# Get general trade routes
get_general_routes = ToolDefinition(
    name="get_general_routes",
    description="Get all active general trade routes, optionally filtered by area.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Optional area ID filter",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum routes to return",
            required=False,
            default=100,
        ),
    ],
    endpoint="/companies/{company_id}/routes/types/general",
    method="GET",
)


# Get modern trade routes
get_modern_routes = ToolDefinition(
    name="get_modern_routes",
    description="Get all active modern trade routes, optionally filtered by area.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Optional area ID filter",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum routes to return",
            required=False,
            default=100,
        ),
    ],
    endpoint="/companies/{company_id}/routes/types/modern",
    method="GET",
)


# Get HORECA routes
get_horeca_routes = ToolDefinition(
    name="get_horeca_routes",
    description="Get all active HORECA (Hotel/Restaurant/Café) routes, optionally filtered by area.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Optional area ID filter",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum routes to return",
            required=False,
            default=100,
        ),
    ],
    endpoint="/companies/{company_id}/routes/types/horeca",
    method="GET",
)


# All route tools
ROUTE_TOOLS = [
    list_routes,
    get_route,
    get_route_by_code,
    get_routes_by_area,
    get_general_routes,
    get_modern_routes,
    get_horeca_routes,
]

