"""
Area-related tools for the agent.

Provides capabilities for:
- Navigating area hierarchy (Nation > Zone > Region > Area > Division)
- Finding areas by name or type
- Getting area-specific data
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# List areas with filtering
list_areas = ToolDefinition(
    name="list_areas",
    description="List areas with optional filtering by type (NATION, ZONE, REGION, AREA, DIVISION) and parent.",
    parameters=[
        ToolParameter(
            name="area_type",
            type="string",
            description="Filter by area type",
            required=False,
            enum=["NATION", "ZONE", "REGION", "AREA", "DIVISION"],
        ),
        ToolParameter(
            name="parent_id",
            type="integer",
            description="Filter by parent area ID",
            required=False,
        ),
        ToolParameter(
            name="parent_type",
            type="string",
            description="Parent type (required if parent_id provided): nation, zone, region, or area",
            required=False,
            enum=["nation", "zone", "region", "area"],
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum results to return (default 20, max 100)",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/companies/{company_id}/areas",
    method="GET",
)


# Get area by ID
get_area = ToolDefinition(
    name="get_area",
    description="Get detailed information about a specific area including all parent references.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="The area ID to retrieve",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/areas/{area_id}",
    method="GET",
)


# Get area by name and type
get_area_by_name = ToolDefinition(
    name="get_area_by_name",
    description="Find an area by its name and type. Useful when user mentions area by name (e.g., 'Mumbai Region', 'North Zone').",
    parameters=[
        ToolParameter(
            name="name",
            type="string",
            description="Area name to search for",
            required=True,
        ),
        ToolParameter(
            name="area_type",
            type="string",
            description="Area type: NATION, ZONE, REGION, AREA, or DIVISION",
            required=True,
            enum=["NATION", "ZONE", "REGION", "AREA", "DIVISION"],
        ),
    ],
    endpoint="/companies/{company_id}/areas/by-name/{area_type}/{name}",
    method="GET",
)


# Get all nations
get_nations = ToolDefinition(
    name="get_nations",
    description="Get all nations (top-level areas). Useful for starting hierarchy navigation.",
    parameters=[],
    endpoint="/companies/{company_id}/areas/hierarchy/nations",
    method="GET",
)


# Get zones by nation
get_zones_by_nation = ToolDefinition(
    name="get_zones_by_nation",
    description="Get all zones under a specific nation.",
    parameters=[
        ToolParameter(
            name="nation_id",
            type="integer",
            description="Nation ID to get zones for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/areas/nation/{nation_id}/zones",
    method="GET",
)


# Get regions by zone
get_regions_by_zone = ToolDefinition(
    name="get_regions_by_zone",
    description="Get all regions under a specific zone.",
    parameters=[
        ToolParameter(
            name="zone_id",
            type="integer",
            description="Zone ID to get regions for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/areas/zone/{zone_id}/regions",
    method="GET",
)


# Get areas by region
get_areas_by_region = ToolDefinition(
    name="get_areas_by_region",
    description="Get all areas under a specific region.",
    parameters=[
        ToolParameter(
            name="region_id",
            type="integer",
            description="Region ID to get areas for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/areas/region/{region_id}/areas",
    method="GET",
)


# Get divisions by area
get_divisions_by_area = ToolDefinition(
    name="get_divisions_by_area",
    description="Get all divisions under a specific area.",
    parameters=[
        ToolParameter(
            name="area_id",
            type="integer",
            description="Area ID to get divisions for",
            required=True,
        ),
    ],
    endpoint="/companies/{company_id}/areas/area/{area_id}/divisions",
    method="GET",
)

create_area = ToolDefinition(
    name="create_area",
    description="Create a new area in the hierarchy. Specify name, type, and parent details.",
    parameters=[
        ToolParameter(
            name="name",
            type="string",
            description="Name of the new area",
            required=True,
        ),
        ToolParameter(
            name="type",
            type="string",
            description="Type of the area: NATION, ZONE, REGION, AREA, or DIVISION",
            required=True,
            enum=["NATION", "ZONE", "REGION", "AREA", "DIVISION"],
        ),
        ToolParameter(
            name="area_id",
            type="integer",
            description="Parent area ID  (required for DIVISION type)",
            required=False,
        ),
        ToolParameter(
            name="region_id",
            type="integer",
            description="Parent region ID (required for AREA types)",
            required=False,
        ),
        ToolParameter(
            name="zone_id",
            type="integer",
            description="Parent zone ID (required for REGION types)",
            required=False,
        ),
        ToolParameter(
            name="nation_id",
            type="integer",
            description="Parent nation ID (required for ZONE types)",
            required=False,
        ),
    ],
    endpoint="/companies/{company_id}/areas",
    method="POST",
)

# All area tools
AREA_TOOLS = [
    list_areas,
    get_area,
    get_area_by_name,
    get_nations,
    get_zones_by_nation,
    get_regions_by_zone,
    get_areas_by_region,
    get_divisions_by_area,
    create_area,
]
