"""
User-related tools for the agent.

Provides capabilities for:
- Listing and searching users (salesmen, managers, etc.)
- Getting user details and assignments
"""

from api.agent.tools.base import ToolDefinition, ToolParameter


# List users by company
list_users = ToolDefinition(
    name="list_users",
    description="List users in the company with optional filtering by active status.",
    parameters=[
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum users to return (default 20, max 100)",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/users/companies/{company_id}/users",
    method="GET",
)


# List users by role
list_users_by_role = ToolDefinition(
    name="list_users_by_role",
    description="List users with a specific role (e.g., 'SALESMAN', 'MANAGER', 'ADMIN').",
    parameters=[
        ToolParameter(
            name="role_name",
            type="string",
            description="Role name to filter by",
            required=True,
        ),
        ToolParameter(
            name="is_active",
            type="boolean",
            description="Filter by active status",
            required=False,
        ),
        ToolParameter(
            name="limit",
            type="integer",
            description="Maximum users to return",
            required=False,
            default=20,
        ),
        ToolParameter(
            name="offset",
            type="integer",
            description="Number to skip for pagination",
            required=False,
            default=0,
        ),
    ],
    endpoint="/users/companies/{company_id}/roles/{role_name}/users",
    method="GET",
)


# Get user by ID
get_user = ToolDefinition(
    name="get_user",
    description="Get detailed information about a specific user including company, area, and role details.",
    parameters=[
        ToolParameter(
            name="user_id",
            type="string",
            description="The user UUID to retrieve",
            required=True,
        ),
    ],
    endpoint="/users/{user_id}",
    method="GET",
    requires_company_id=False,
)


# Get user by username
get_user_by_username = ToolDefinition(
    name="get_user_by_username",
    description="Find a user by their username.",
    parameters=[
        ToolParameter(
            name="username",
            type="string",
            description="Username to search for",
            required=True,
        ),
    ],
    endpoint="/users/username/{username}",
    method="GET",
    requires_company_id=False,
)


# All user tools
USER_TOOLS = [
    list_users,
    list_users_by_role,
    get_user,
    get_user_by_username,
]

